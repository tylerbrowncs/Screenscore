
import axios from "axios"

axios.post("http://localhost:44354/register", {
    username: "TylerBrown"
}
)